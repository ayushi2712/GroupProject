package com.cg.university.service;

import java.time.LocalDate;
import java.util.ArrayList;

import com.cg.university.dao.IMacDao;
import com.cg.university.dao.MacDaoImpl;
import com.cg.university.entities.ApplicationForm;
import com.cg.university.exception.UniversityException;

public class MacServiceImpl implements IMacService {
	
	private IMacDao macDao;
	
	public MacServiceImpl() {
		super();
		macDao = new MacDaoImpl();
	}

	@Override
	public ArrayList<ApplicationForm> showAllApplicationForms() throws UniversityException {
		return macDao.showAllApplicationForms();
	}

	@Override
	public ApplicationForm searchFormById(int id) throws UniversityException {
		return macDao.searchFormById(id);
	}

	@Override
	public ApplicationForm changeStatusOfApplicationForm(ApplicationForm applicationForm, String setStatus)
			throws UniversityException 
	{
		return macDao.changeStatusOfApplicationForm(applicationForm, setStatus);
	}

	@Override
	public ApplicationForm changeStatusOfApplicationForm(ApplicationForm applicationForm, String setStatus,
			LocalDate dateOfInterview) throws UniversityException 
	{
		return macDao.changeStatusOfApplicationForm(applicationForm, setStatus, dateOfInterview);
	}

}
