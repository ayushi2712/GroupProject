package com.cg.university.service;

import com.cg.university.entities.LoginReturnValues;
import com.cg.university.entities.Users;
import com.cg.university.exception.UniversityException;

public interface ILoginService {
	LoginReturnValues authentication(Users users, LoginReturnValues loginReturnValues) throws UniversityException;

}
