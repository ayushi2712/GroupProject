package com.cg.university.service;

import java.util.ArrayList;
import java.util.List;

import com.cg.university.dao.AdminDaoImpl;
import com.cg.university.dao.IAdminDao;
import com.cg.university.entities.ProgramOffered;
import com.cg.university.entities.ProgramsScheduled;
import com.cg.university.exception.UniversityException;

public class AdminServiceImpl implements IAdminService {
	
	private IAdminDao adminDao;
	
	public AdminServiceImpl() {
		super();
		adminDao = new AdminDaoImpl();
	}

	@Override
	public void addProgram(ProgramOffered programOffred, ProgramsScheduled programScheduled)
			throws UniversityException {
		adminDao.addProgram(programOffred, programScheduled);
	}

	@Override
	public ArrayList<ProgramOffered> showAllProgramOffered() throws UniversityException {
		return adminDao.showAllProgramOffered();
	}

	@Override
	public ArrayList<ProgramsScheduled> showAllProgramScheduled() throws UniversityException {
		// TODO Auto-generated method stub
		return adminDao.showAllProgramScheduled();
	}

	@Override
	public ProgramOffered deleteProgramOffered(String programName) throws UniversityException {
		return adminDao.deleteProgramOffered(programName);
	}

	@Override
	public ProgramsScheduled deleteProgramsScheduled(String programName) throws UniversityException {
		return adminDao.deleteProgramsScheduled(programName);
	}

}
