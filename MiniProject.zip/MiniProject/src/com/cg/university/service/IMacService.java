package com.cg.university.service;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import com.cg.university.entities.ApplicationForm;
import com.cg.university.exception.UniversityException;

public interface IMacService {
	
	ArrayList<ApplicationForm> showAllApplicationForms() throws UniversityException;
	ApplicationForm searchFormById(int id) throws UniversityException;
	ApplicationForm changeStatusOfApplicationForm(ApplicationForm applicationForm, String setStatus)
			throws UniversityException;
	ApplicationForm changeStatusOfApplicationForm(ApplicationForm applicationForm, String setStatus,
			LocalDate dateOfInterview) throws UniversityException;

}
