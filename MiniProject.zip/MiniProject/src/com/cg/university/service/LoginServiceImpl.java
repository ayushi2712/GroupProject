package com.cg.university.service;

import com.cg.university.dao.ILoginDao;
import com.cg.university.dao.LoginDaoImpl;
import com.cg.university.entities.LoginReturnValues;
import com.cg.university.entities.Users;
import com.cg.university.exception.UniversityException;

public class LoginServiceImpl implements ILoginService {

	private ILoginDao loginDao;
	
	public LoginServiceImpl() {
		super();
		loginDao = new LoginDaoImpl();
	}

	@Override
	public LoginReturnValues authentication(Users users, LoginReturnValues loginReturnValues)
			throws UniversityException {
		// TODO Auto-generated method stub
		return loginDao.authentication(users, loginReturnValues);
	}

}
