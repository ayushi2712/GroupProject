package com.cg.university.service;

import com.cg.university.entities.ApplicationForm;
import com.cg.university.exception.UniversityException;

public interface IApplicantService {
	
	public int fillApplicationForm(ApplicationForm applicationForm) throws UniversityException;
	String viewApplicationStatus(int id) throws UniversityException;
	boolean validateName(String name);
	boolean validatePhone(String phone);
	boolean validateEmail(String email);

}
