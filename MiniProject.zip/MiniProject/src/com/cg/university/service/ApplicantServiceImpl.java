package com.cg.university.service;

import java.util.regex.Pattern;

import com.cg.university.dao.ApplicantDaoImpl;
import com.cg.university.dao.IApplicantDao;
import com.cg.university.entities.ApplicationForm;
import com.cg.university.exception.UniversityException;

public class ApplicantServiceImpl implements IApplicantService {
	
	private IApplicantDao applicantDao;
	
	public ApplicantServiceImpl() {
		super();
		applicantDao = new ApplicantDaoImpl();
	}

	@Override
	public int fillApplicationForm(ApplicationForm applicationForm) throws UniversityException {
		// TODO Auto-generated method stub
		return applicantDao.fillApplicationForm(applicationForm);
	}

	@Override
	public String viewApplicationStatus(int id) throws UniversityException {
		// TODO Auto-generated method stub
		return applicantDao.viewApplicationStatus(id);
	}
	
	@Override
	public boolean validateName(String name) {

	 String pattern = "[A-Z]{1}[a-z]{2,19}";
	 if (Pattern.matches(pattern, name)) {
	  return true;
	 } else
	  return false;
	}
	
	@Override
	public boolean validatePhone(String phone) {

	 String pattern = "[1-9]{1}[0-9]{9}";
	 if (Pattern.matches(pattern, phone)) {
	  return true;
	 } else
	  return false;
	}
	
	@Override
	public boolean validateEmail(String email) {

	 String pattern = "^[_A-Za-z0-9-\\+]+(\\.[_A-Za-z0-9-]+)*@"
	   + "[A-Za-z0-9-]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,})$";
	 if (Pattern.matches(pattern, email)) {
	  return true;
	 } else
	  return false;
	}

}
