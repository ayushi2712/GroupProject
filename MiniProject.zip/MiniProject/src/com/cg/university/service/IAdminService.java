package com.cg.university.service;

import java.util.ArrayList;
import java.util.List;

import com.cg.university.entities.ProgramOffered;
import com.cg.university.entities.ProgramsScheduled;
import com.cg.university.exception.UniversityException;

public interface IAdminService {
	
	void addProgram(ProgramOffered programOffred, ProgramsScheduled programScheduled) throws UniversityException;
	ArrayList<ProgramOffered> showAllProgramOffered() throws UniversityException;
	ArrayList<ProgramsScheduled> showAllProgramScheduled() throws UniversityException;
	ProgramOffered deleteProgramOffered(String programName) throws UniversityException;
	ProgramsScheduled deleteProgramsScheduled(String programName) throws UniversityException;

}
