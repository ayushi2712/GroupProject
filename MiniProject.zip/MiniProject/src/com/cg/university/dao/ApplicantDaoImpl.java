package com.cg.university.dao;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.cg.university.entities.ApplicationForm;
import com.cg.university.exception.UniversityException;

@Repository
@Transactional
public class ApplicantDaoImpl implements IApplicantDao {

	@PersistenceContext
	private EntityManager entityManager;

	@Override
	public ApplicationForm fillApplicationForm(ApplicationForm applicationForm)
			throws UniversityException {
		entityManager.persist(applicationForm);
		entityManager.flush();
		return applicationForm;

	}

	@Override
	public ApplicationForm viewApplicationStatus(int id)
			throws UniversityException {
		return entityManager.find(ApplicationForm.class, id);
		// return entityManager.find(DonorBean.class, donorId);
	}
}