package com.cg.university.dao;

import com.cg.university.entities.ApplicationForm;
import com.cg.university.exception.UniversityException;

public interface IApplicantDao {

	public ApplicationForm fillApplicationForm(ApplicationForm applicationForm) throws UniversityException;
	ApplicationForm viewApplicationStatus(int id) throws UniversityException;

}
