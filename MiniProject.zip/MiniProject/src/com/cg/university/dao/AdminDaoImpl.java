package com.cg.university.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.cg.university.entities.ProgramOffered;
import com.cg.university.entities.ProgramsScheduled;
import com.cg.university.exception.UniversityException;

@Repository
public class AdminDaoImpl implements IAdminDao {

	@PersistenceContext
	private EntityManager entityManager;

	@Override
	public void addProgram(ProgramOffered programOffred,
			ProgramsScheduled programScheduled) throws UniversityException {
		entityManager.persist(programOffred);
		entityManager.persist(programScheduled);
		entityManager.flush();
	}

	@Override
	public List<ProgramOffered> showAllProgramOffered()
			throws UniversityException {
		TypedQuery<ProgramOffered> query = entityManager.createQuery(
				"SELECT p FROM ProgramOffered p", ProgramOffered.class);
		return query.getResultList();
	}

	@Override
	public List<ProgramsScheduled> showAllProgramScheduled()
			throws UniversityException {
		TypedQuery<ProgramsScheduled> query = entityManager.createQuery(
				"SELECT s FROM ProgramsScheduled s", ProgramsScheduled.class);
		return query.getResultList();
	}

	@Override
	public ProgramOffered deleteProgramOffered(String programName)
			throws UniversityException {
		ProgramOffered p1 = entityManager.find(ProgramOffered.class,
				programName);
		entityManager.remove(p1);
		return p1;
	}

	@Override
	public ProgramsScheduled deleteProgramsScheduled(String programName)
			throws UniversityException {
		ProgramsScheduled p2 = entityManager.find(ProgramsScheduled.class,
				programName);
		entityManager.remove(p2);
		return p2;
	}
}
