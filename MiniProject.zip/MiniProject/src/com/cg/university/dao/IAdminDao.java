package com.cg.university.dao;


import java.util.List;

import com.cg.university.entities.ProgramOffered;
import com.cg.university.entities.ProgramsScheduled;
import com.cg.university.exception.UniversityException;

public interface IAdminDao {

	void addProgram(ProgramOffered programOffred, ProgramsScheduled programScheduled) throws UniversityException;
    List<ProgramOffered> showAllProgramOffered() throws UniversityException;
    List<ProgramsScheduled> showAllProgramScheduled() throws UniversityException;
	ProgramOffered deleteProgramOffered(String programName) throws UniversityException;
	ProgramsScheduled deleteProgramsScheduled(String programName) throws UniversityException;

}
