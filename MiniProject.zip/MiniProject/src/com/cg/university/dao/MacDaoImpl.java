package com.cg.university.dao;

import java.time.LocalDate;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.cg.university.entities.ApplicationForm;
import com.cg.university.exception.UniversityException;

@Repository
public class MacDaoImpl implements IMacDao {
	@PersistenceContext
	private EntityManager entityManager;

	@Override
	public List<ApplicationForm> showAllApplicationForms()
			throws UniversityException {
		TypedQuery<ApplicationForm> query = entityManager.createQuery(
				"SELECT a FROM ApplicationForm a", ApplicationForm.class);
		return query.getResultList();
	}

	@Override
	public ApplicationForm searchFormById(int id) throws UniversityException {
		return entityManager.find(ApplicationForm.class, id);
	}

	@Override
	public ApplicationForm changeStatusOfApplicationForm(
			ApplicationForm applicationForm, String setStatus)
			throws UniversityException {
		entityManager.merge(applicationForm);
		// entityManager.merge(setStatus);
		return applicationForm;
	}

	@Override
	public ApplicationForm changeStatusOfApplicationForm(
			ApplicationForm applicationForm, String setStatus,
			LocalDate dateOfInterview) throws UniversityException {
		return entityManager.merge(applicationForm);
	}
}