package com.cg.university.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.apache.log4j.Logger;

import com.cg.university.entities.LoginReturnValues;
import com.cg.university.entities.Users;
import com.cg.university.exception.UniversityException;
import com.cg.university.logger.MyLogger;
import com.cg.university.util.DBUtil;




public class LoginDaoImpl implements ILoginDao {

	Connection con;
	Logger logger;

	public LoginDaoImpl() {
		con = DBUtil.getConnect();
		logger = MyLogger.getLogger();
	}

	@Override
	public LoginReturnValues authentication(Users users, LoginReturnValues loginReturnValues)
			throws UniversityException 
	{	
		String enteredPassword = users.getPassword();
		String dbPassword = null;
		loginReturnValues.setRole(null);
		loginReturnValues.setSuccess(false);
		int id = users.getId();
		
		String qry = "SELECT password,role FROM users WHERE id = ?";
		try {
			PreparedStatement pstmt = con.prepareStatement(qry);
			pstmt.setInt(1, id);
			ResultSet rs = pstmt.executeQuery();
			if (rs.next()) {
				dbPassword = rs.getString("password");
				String role = rs.getString("role");
				if (dbPassword.equals(enteredPassword)) {
					logger.info(users.getId() + "Logged in");
					loginReturnValues.setRole(role);
					loginReturnValues.setSuccess(true);
				} else {
					throw new UniversityException("Id and Password do not match!");
				}
			} else {
				throw new UniversityException("Id do not exist!");
			}
		} catch (SQLException e) {
			throw new UniversityException(e.getMessage());
		}
		return loginReturnValues;
	}

}
