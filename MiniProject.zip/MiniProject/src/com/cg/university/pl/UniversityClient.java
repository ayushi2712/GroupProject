package com.cg.university.pl;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Scanner;

import org.omg.CORBA.PUBLIC_MEMBER;

import com.cg.university.dao.ILoginDao;
import com.cg.university.dao.LoginDaoImpl;
import com.cg.university.entities.ApplicationForm;
import com.cg.university.entities.LoginReturnValues;
import com.cg.university.entities.ProgramOffered;
import com.cg.university.entities.ProgramsScheduled;
import com.cg.university.entities.Users;
import com.cg.university.exception.UniversityException;
import com.cg.university.service.AdminServiceImpl;
import com.cg.university.service.ApplicantServiceImpl;
import com.cg.university.service.IAdminService;
import com.cg.university.service.IApplicantService;
import com.cg.university.service.ILoginService;
import com.cg.university.service.IMacService;
import com.cg.university.service.LoginServiceImpl;
import com.cg.university.service.MacServiceImpl;

public class UniversityClient {
	
	public static ILoginService loginService = new LoginServiceImpl();
	public static IAdminService adminService = new AdminServiceImpl();
	public static IMacService macService = new MacServiceImpl();
	public static IApplicantService applicantService = new ApplicantServiceImpl();

	public static void main(String[] args) {
		
		
		
		ArrayList<ProgramOffered> programOffered = new ArrayList<ProgramOffered>();
		ArrayList<ProgramsScheduled> programsScheduled = new ArrayList<ProgramsScheduled>();
		
		System.out.println("WELCOME TO XYZ UNIVERSITY");
		
		Scanner scan = new Scanner(System.in);
		String stringInput = null;
		int intInput = 0;
		int id = 0;
		int choice = 0;
		do 
		{
			System.out.print("1-> View Programs Offered\n"
					+ "2-> View Programs Schedule\n"
					+ "3-> Fill Application Form\n"
					+ "4-> Check Application Status\n"
					+ "5-> Login(University Members Only)\n"
					+ "6-> Exit Application\n"
					+ ">>");
			choice = scan.nextInt();
			switch(choice)
			{
				case 1:
					try 
					{
						programOffered = adminService.showAllProgramOffered();
						for(ProgramOffered ele : programOffered)
							System.out.println(ele);
					}catch (UniversityException e) {
						System.out.println(e.getMessage());
					}
					break;
					
				case 2:
					try 
					{
						programsScheduled = adminService.showAllProgramScheduled();
						for(ProgramsScheduled ele : programsScheduled)
							System.out.println(ele);
					}catch (UniversityException e) {
						System.out.println(e.getMessage());
					}
					break;
					
				case 3:
					try 
					{
						acceptApplicantionForm();				
					} catch (UniversityException e) 
					{
						System.out.println(e.getMessage());
					}
					break;
					
				case 4:
					try 
					{
						System.out.print("Enter Your Id>>");
						System.out.println(applicantService.viewApplicationStatus(scan.nextInt()));							
					} catch (UniversityException e) 
					{
						System.out.println(e.getMessage());
					}
					break;
				
				case 5:
					Users user = new Users();
					LoginReturnValues loginReturnValue = new LoginReturnValues();
					System.out.print("Enter ID>>");
					user.setId(scan.nextInt());
					System.out.print("Enter Password>>");
					user.setPassword(scan.next());
					try 
					{
						loginReturnValue = loginService.authentication(user, loginReturnValue);
						if(loginReturnValue.isSuccess())
						{
							if(loginReturnValue.getRole().equals("mac"))
							{
								int innerChoice = 0;
								do 
								{
									System.out.print("1->Show All Application Forms\n"
											+ "2-> Search Form By Id\n"
											+ "3-> Change Status Of Application Form By Id\n"
											+ "4-> Logout\n >>");
									ArrayList<ApplicationForm> applicationFormsList = null;
									ApplicationForm applicationForm = null;
									innerChoice = scan.nextInt();
									switch (innerChoice) {
									case 1:
										applicationFormsList = new ArrayList<ApplicationForm>();
										applicationFormsList = macService.showAllApplicationForms();
										for(ApplicationForm ele : applicationFormsList)
											System.out.println(ele);
										break;
										
									case 2:
										try 
										{
											System.out.print("Enter Application Form Id>>");
											System.out.println(macService.searchFormById(scan.nextInt()));		
										} catch (UniversityException e) 
										{
											System.out.println(e.getMessage());
										}
										break;
										
									case 3:
										System.out.print("Enter Application Form Id>>");
										id = scan.nextInt();
										System.out.print("Enter Status>>");
										stringInput = scan.next();
										try 
										{
											applicationForm = macService.searchFormById(id);
											if(stringInput.equals("Rejected") || stringInput.equals("Confirmed"))
											{
												applicationForm = macService.changeStatusOfApplicationForm(applicationForm, stringInput);
												System.out.println("Application form havivg id:" + id + " is " + stringInput);
											}
												
											else
											{
												System.out.println("--Enter Interview Date--");
												System.out.print("Enter Day>>");
												int day = scan.nextInt();
												System.out.print("Enter Month>>");
												int month = scan.nextInt();
												System.out.print("Enter Year>>");
												int year = scan.nextInt();
												applicationForm = macService.changeStatusOfApplicationForm(applicationForm, stringInput, LocalDate.of(year, month, day));	
												System.out.println("Application form havivg id:" + id + " is " + stringInput + "and Interview Date is on " + LocalDate.of(year, month, day));
											}
										} catch (UniversityException e) 
										{
											System.out.println(e.getMessage());
										}
										break;
										
									case 4:
										innerChoice = 4;
										break;
										
									default:
										System.out.println("Enter Proper Option!!");
										break;
									}
								} while (innerChoice != 4);
								
							}
							else if (loginReturnValue.getRole().equals("admin")) 
							{
								int innerChoice = 0;
								do 
								{	
									System.out.print("1-> Add Program Offered and Program Scheduled\n"
											+ "2-> Delete Program Offered\n"
											+ "3-> Delete Program Scheduled\n"
											+ "4-> Logout\n>>");
									innerChoice= scan.nextInt();
									switch(innerChoice)
									{
										case 1:
											ProgramOffered programOffered2 = new ProgramOffered();
											ProgramsScheduled programsScheduled2 = new ProgramsScheduled();
											try
											{
												System.out.println("Enter Program Name");
												programOffered2.setProgramName(scan.next());
												System.out.println("Enter Program Description:");
												programOffered2.setDescription(scan.next());
												System.out.println("Enter Program Eligibility");
												programOffered2.setEligibility(scan.next());
												System.out.println("Enter Program Duration(years)");
												programOffered2.setDuration(scan.nextInt());
												System.out.println("Degree Certificate Offered");
												programOffered2.setDegreeCertificateOffered(scan.next());
												System.out.println("Enter Program Scheduled Id");
												programsScheduled2.setScheduledProgramId(scan.nextInt());
												System.out.println("Enter Program Location");
												programsScheduled2.setLocation(scan.next());
												System.out.println("--Enter Program Start Date--");
												System.out.print("Enter Day>>");
												int day = scan.nextInt();
												System.out.print("Enter Month>>");
												int month = scan.nextInt();
												System.out.print("Enter Year>>");
												int year = scan.nextInt();
												programsScheduled2.setStartDate(LocalDate.of(year, month, day));
												System.out.println("--Enter Program End Date--");
												System.out.print("Enter Day>>");
												day = scan.nextInt();
												System.out.print("Enter Month>>");
												month = scan.nextInt();
												System.out.print("Enter Year>>");
												year = scan.nextInt();
												programsScheduled2.setEndDate(LocalDate.of(year, month, day));
												System.out.println("Enter Session Per Week");
												programsScheduled2.setSessionPerWeek(scan.nextInt());
												adminService.addProgram(programOffered2, programsScheduled2);	
											}catch(UniversityException e)
											{
												System.out.println(e.getMessage());
											}
											break;
											
										case 2:
											System.out.println("Enter Program Name:");
											try 
											{
												System.out.println("Deleted " + adminService.deleteProgramOffered(scan.next()));
												
											} catch (UniversityException e) 
											{
												System.out.println(e.getMessage());
											}
											break;
											
										case 3:
											System.out.println("Enter Program Name:");
											try 
											{
												System.out.println("Deleted " + adminService.deleteProgramsScheduled(scan.next()));
												
											} catch (UniversityException e) 
											{
												System.out.println(e.getMessage());
											}
											break;
										case 4:
											innerChoice = 4;
											break;
										default:
											System.out.println("Enter Proper Option!!");
											break;
											
									}
								} while (innerChoice != 4);
							}
						}
						
					} catch (UniversityException e) {
						System.out.println(e.getMessage());
					}
					break;
				case 6:
					System.out.println("Exiting Application");
					System.exit(1);
				default:
					System.out.println("Please Choose Correct Option");
			}
		} while (choice!=6);	
	}
	
	
	public static void acceptApplicantionForm() throws UniversityException
	{
		ApplicationForm applicationForm = new ApplicationForm();
		Scanner scan = new Scanner(System.in);
		
		boolean whileFlag = true;
		boolean fNameFlag = true;
		boolean lNameFlag = true;
		boolean emailFlag = true;
		boolean nextFlag = true;
		
		String fName = null;
		String lName = null;
		String email = null;
		
		int id = 0;
		while(whileFlag)
		{
			if(fNameFlag)
			{
				System.out.print("Enter Your First Name>>");
				fName = scan.next();
				fNameFlag = !applicantService.validateName(fName);
				continue;
			}
			if(lNameFlag)
			{
				System.out.print("Enter Your Last Name>>");
				lName = scan.next();
				lNameFlag = !applicantService.validateName(lName);
				continue;
			}
			if(emailFlag)
			{
				System.out.print("Enter Your Email>>");
				email = scan.next();
				emailFlag = !applicantService.validateEmail(email);
				continue;
			}
			if(nextFlag)
			{
				applicationForm.setName(fName + " " + lName);
				System.out.println("--Enter Your Date Of Birth--");
				System.out.print("Enter Day>>");
				int day = scan.nextInt();
				System.out.print("Enter Month>>");
				int month = scan.nextInt();
				System.out.print("Enter Year>>");
				int year = scan.nextInt();
				applicationForm.setDob(LocalDate.of(year, month, day));
				System.out.print("Enter Qualification>>");
				applicationForm.setQualification(scan.next());
				System.out.print("Enter marks>>");
				applicationForm.setMarks(scan.nextInt());
				System.out.print("Enter Goal>>");
				applicationForm.setGoals(scan.next());
				applicationForm.setEmail(email);
				System.out.print("Enter Scheduled Program Id>>");
				applicationForm.setScheduledProgramId(scan.nextInt());
				id = applicantService.fillApplicationForm(applicationForm);
				System.out.println("Application Form Successfully Registered Having Id: " + id);
				whileFlag = false;
			}
		}
	}
	
}
